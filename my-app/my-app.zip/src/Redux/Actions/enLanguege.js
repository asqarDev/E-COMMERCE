export const enLanguege=()=>{
    return{
        type:'en'
    }
}