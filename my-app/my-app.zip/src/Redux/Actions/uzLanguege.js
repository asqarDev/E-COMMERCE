export const uzLanguege=()=>{
    return{
        type:'uz'
    }
}