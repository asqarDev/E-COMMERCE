export const ruLanguege=()=>{
    return{
        type:'ru'
    }
}