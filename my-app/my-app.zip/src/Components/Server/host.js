import axios from "axios";
export let host = "http://admin.sciennet.uz/uz";
export let hosten = "http://admin.sciennet.uz/en";
export let hostru = "http://admin.sciennet.uz/ru";
export let host1='http://admin.sciennet.uz';

export let HttpRequest=(config)=>{
    return axios({
        url:host,
        url:host1,
        ...config,
    })
}
